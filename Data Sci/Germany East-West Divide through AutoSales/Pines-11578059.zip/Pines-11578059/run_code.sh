#!/bin/sh

python 315CourseProject.py